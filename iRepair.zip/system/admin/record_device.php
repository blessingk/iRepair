<?php
session_start();
include("../dbcon.php");
$user=$_SESSION['username'];
$sql = "select * from users where username = '$user' ";
$result = $pdo->query($sql);
$row = $result->fetch();

$FirstName=$row['first_name'];
$LastName=$row['last_name'];
$username=$row['username'];
$mail=$row['email'];
$gender=$row['gender'];
$phone=$row['phone'];
$adr=$row['address'];
$acc=$row['design'];
$role=$row['design'];
if(!$user){
    header("location: ../index.php");
    echo "document expired";
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Keltech Repairs">
    <meta name="author" content="Keltech Repairs">
    <meta name="keyword" content="keltech repairs">
    <link rel="shortcut icon" href="img/favicon.png">
    <title>Keltech Repairs</title>

    <!-- Bootstrap CSS -->
    <link href="../css/bootstrap.min.css" rel="stylesheet">
    <!-- bootstrap theme -->
    <link href="../css/bootstrap-theme.css" rel="stylesheet">
    <!--external css-->
    <!-- font icon -->
    <link href="../css/elegant-icons-style.css" rel="stylesheet" />
    <link href="../css/font-awesome.min.css" rel="stylesheet" />
    <!-- Custom styles -->
    <link href="../css/style.css" rel="stylesheet">
    <link href="../css/style-responsive.css" rel="stylesheet" />

    <!-- HTML5 shim and Respond.js IE8 support of HTML5 -->
    <!--[if lt IE 9]>
    <script src="../js/html5shiv.js"></script>
    <script src="js/respond.min.js"></script>
    <script src="../js/lte-ie7.js"></script>
    <![endif]-->


</head>

<body>
<!-- container section start -->
<section id="container" class="">


    <header class="header dark-bg">
        <div class="toggle-nav">
            <div class="icon-reorder tooltips" data-original-title="Toggle Navigation" data-placement="bottom"><i class="icon_menu"></i></div>
        </div>

        <!--logo start-->
        <a href="index.php" class="logo"><img src="../img/keltechlogo.png" class="img-rounded" style="width: 10%"> <span class="lite">Keltech Repairs</span></a>
        <!--logo end-->

        <div class="nav search-row" id="top_menu">
            <!--  search form start --
            <ul class="nav top-menu">
                <li>
                    <form class="navbar-form">
                        <input class="form-control" placeholder="Search" type="text">
                    </form>
                </li>
            </ul>
            <!--  search form end -->
        </div>

        <div class="top-nav notification-row">
            <!-- notificatoin dropdown start-->
            <ul class="nav pull-right top-menu">

                <!-- task notificatoin start -->
                <li id="task_notificatoin_bar" class="dropdown">
                    <a data-toggle="dropdown" class="dropdown-toggle" href="#">
                        <!--<i class="icon-task-l"></i>
                        <span class="badge bg-important">6</span>-->
                    </a>
                    <ul class="dropdown-menu extended tasks-bar">
                        <div class="notify-arrow notify-arrow-blue"></div>
                        <li>
                            <p class="blue">You have 6 pending letter</p>
                        </li>
                        <li>
                            <a href="#">
                                <div class="task-info">
                                    <div class="desc">Design PSD </div>
                                    <div class="percent">90%</div>
                                </div>
                                <div class="progress progress-striped">
                                    <div class="progress-bar progress-bar-success" role="progressbar" aria-valuenow="90" aria-valuemin="0" aria-valuemax="100" style="width: 90%">
                                        <span class="sr-only">90% Complete (success)</span>
                                    </div>
                                </div>
                            </a>
                        </li>
                        <li>
                            <a href="#">
                                <div class="task-info">
                                    <div class="desc">
                                        Project 1
                                    </div>
                                    <div class="percent">30%</div>
                                </div>
                                <div class="progress progress-striped">
                                    <div class="progress-bar progress-bar-warning" role="progressbar" aria-valuenow="30" aria-valuemin="0" aria-valuemax="100" style="width: 30%">
                                        <span class="sr-only">30% Complete (warning)</span>
                                    </div>
                                </div>
                            </a>
                        </li>
                        <li>
                            <a href="#">
                                <div class="task-info">
                                    <div class="desc">Digital Marketing</div>
                                    <div class="percent">80%</div>
                                </div>
                                <div class="progress progress-striped">
                                    <div class="progress-bar progress-bar-info" role="progressbar" aria-valuenow="80" aria-valuemin="0" aria-valuemax="100" style="width: 80%">
                                        <span class="sr-only">80% Complete</span>
                                    </div>
                                </div>
                            </a>
                        </li>
                        <li>
                            <a href="#">
                                <div class="task-info">
                                    <div class="desc">Logo Designing</div>
                                    <div class="percent">78%</div>
                                </div>
                                <div class="progress progress-striped">
                                    <div class="progress-bar progress-bar-danger" role="progressbar" aria-valuenow="78" aria-valuemin="0" aria-valuemax="100" style="width: 78%">
                                        <span class="sr-only">78% Complete (danger)</span>
                                    </div>
                                </div>
                            </a>
                        </li>
                        <li>
                            <a href="#">
                                <div class="task-info">
                                    <div class="desc">Mobile App</div>
                                    <div class="percent">50%</div>
                                </div>
                                <div class="progress progress-striped active">
                                    <div class="progress-bar" role="progressbar" aria-valuenow="50" aria-valuemin="0" aria-valuemax="100" style="width: 50%">
                                        <span class="sr-only">50% Complete</span>
                                    </div>
                                </div>

                            </a>
                        </li>
                        <li class="external">
                            <a href="#">See All Tasks</a>
                        </li>
                    </ul>
                </li>
                <!-- task notificatoin end -->
                <!-- inbox notificatoin start-->
                <li id="mail_notificatoin_bar" class="dropdown">
                    <a data-toggle="dropdown" class="dropdown-toggle" href="#">
                        <!--<i class="icon-envelope-l"></i>
                        <span class="badge bg-important">5</span>-->
                    </a>
                    <ul class="dropdown-menu extended inbox">
                        <div class="notify-arrow notify-arrow-blue"></div>
                        <li>
                            <p class="blue">You have 5 new messages</p>
                        </li>
                        <li>
                            <a href="#">
                                <span class="photo"><img alt="avatar" src="../img/avatar-mini.jpg"></span>
                                <span class="subject">
                                    <span class="from">Greg  Martin</span>
                                    <span class="time">1 min</span>
                                    </span>
                                <span class="message">
                                        I really like this admin panel.
                                    </span>
                            </a>
                        </li>
                        <li>
                            <a href="#">
                                <span class="photo"><img alt="avatar" src="../img/avatar-mini2.jpg"></span>
                                <span class="subject">
                                    <span class="from">Bob   Mckenzie</span>
                                    <span class="time">5 mins</span>
                                    </span>
                                <span class="message">
                                     Hi, What is next project plan?
                                    </span>
                            </a>
                        </li>
                        <li>
                            <a href="#">
                                <span class="photo"><img alt="avatar" src="../img/avatar-mini3.jpg"></span>
                                <span class="subject">
                                    <span class="from">Phillip   Park</span>
                                    <span class="time">2 hrs</span>
                                    </span>
                                <span class="message">
                                        I am like to buy this Admin Template.
                                    </span>
                            </a>
                        </li>
                        <li>
                            <a href="#">
                                <span class="photo"><img alt="avatar" src="../img/avatar-mini4.jpg"></span>
                                <span class="subject">
                                    <span class="from">Ray   Munoz</span>
                                    <span class="time">1 day</span>
                                    </span>
                                <span class="message">
                                        Icon fonts are great.
                                    </span>
                            </a>
                        </li>
                        <li>
                            <a href="#">See all messages</a>
                        </li>
                    </ul>
                </li>
                <!-- inbox notificatoin end -->
                <!-- alert notification start-->
                <li id="alert_notificatoin_bar" class="dropdown">
                    <a data-toggle="dropdown" class="dropdown-toggle" href="#">

                        <!--<i class="icon-bell-l"></i>
                        <span class="badge bg-important">7</span>-->
                    </a>
                    <ul class="dropdown-menu extended notification">
                        <div class="notify-arrow notify-arrow-blue"></div>
                        <li>
                            <p class="blue">You have 4 new notifications</p>
                        </li>
                        <li>
                            <a href="#">
                                <span class="label label-primary"><i class="icon_profile"></i></span>
                                Friend Request
                                <span class="small italic pull-right">5 mins</span>
                            </a>
                        </li>
                        <li>
                            <a href="#">
                                <span class="label label-warning"><i class="icon_pin"></i></span>
                                John location.
                                <span class="small italic pull-right">50 mins</span>
                            </a>
                        </li>
                        <li>
                            <a href="#">
                                <span class="label label-danger"><i class="icon_book_alt"></i></span>
                                Project 3 Completed.
                                <span class="small italic pull-right">1 hr</span>
                            </a>
                        </li>
                        <li>
                            <a href="#">
                                <span class="label label-success"><i class="icon_like"></i></span>
                                Mick appreciated your work.
                                <span class="small italic pull-right"> Today</span>
                            </a>
                        </li>
                        <li>
                            <a href="#">See all notifications</a>
                        </li>
                    </ul>
                </li>
                <!-- alert notification end-->
                <!-- user login dropdown start-->
                <li class="dropdown">
                    <a data-toggle="dropdown" class="dropdown-toggle" href="#">
                            <span class="profile-ava">
                               <i class="icon_profile"></i>
                            </span>
                        <span class="username"><?php echo $FirstName." ". $LastName; ?></span>
                        <b class="caret"></b>
                    </a>
                    <ul class="dropdown-menu extended logout">
                        <div class="log-arrow-up"></div>
                        <li class="eborder-top">
                            <a href="admin_profile.php"><i class="icon_profile"></i> My Profile</a>
                        </li>
                        <li>
                            <a href="#"><i class="icon_mail_alt"></i> My Inbox</a>
                        </li>
                        <li>
                            <!--<a href="#"><i class="icon_clock_alt"></i> Timeline</a>-->
                        </li>
                        <li>
                            <a href="#"><i class="icon_chat_alt"></i> Chats</a>
                        </li>
                        <li>
                            <a href="../logout.php"><i class="icon_key_alt"></i> Log Out</a>
                        </li>
                        <li>
                            <!-- <a href="documentation.html"><i class="icon_key_alt"></i> Documentation</a>
                           </li>
                           <li>
                             <a href="documentation.html"><i class="icon_key_alt"></i> Documentation</a>-->
                        </li>
                    </ul>
                </li>
                <!-- user login dropdown end -->
            </ul>
            <!-- notificatoin dropdown end-->
        </div>
    </header>
    <!--header end-->

    <!--sidebar start-->
    <aside>
        <div id="sidebar" class="nav-collapse ">
            <!-- sidebar menu start-->
            <ul class="sidebar-menu">
                <li class="active">
                    <a class="" href="index.php">
                        <i class="icon_house_alt"></i>
                        <span>Home</span>
                    </a>
                </li>
                <li class="sub-menu">
                    <a href="javascript:;" class="">
                        <i class="icon_laptop"></i>
                        <span>Devices</span>
                        <span class="menu-arrow arrow_carrot-right"></span>
                    </a>
                    <ul class="sub">
                        <li><a class="" href="record_device.php">Record Devices</a></li>
                    </ul>
                </li>
                <li class="sub-menu">
                    <a href="javascript:;" class="">
                        <i class="icon_book_alt"></i>
                        <span>Accounts</span>
                        <span class="menu-arrow arrow_carrot-right"></span>
                    </a>
                    <ul class="sub">
                        <li><a class="" href="invoices.php">Create Invoices</a></li>
                        <li><a class="" href="quotation.php">Create Quotations</a></li>
                        <li><a class="" href="receipts.php">Receipts</a></li>
                        <li><a class="" href="stock_take.php">Record Stocks</a></li>
                    </ul>
                </li>
                <li class="sub-menu">
                    <a href="javascript:;" class="">
                        <i class="icon_book_alt"></i>
                        <span>User accounts</span>
                        <span class="menu-arrow arrow_carrot-right"></span>
                    </a>
                    <ul class="sub">
                        <li><a class="" href="create_user.php">Create users</a></li>
                        <li><a class="" href="view_users.php">View Users</a></li>
                    </ul>
                </li>
                <li class="sub-menu">
                    <a href="javascript:;" class="">
                        <i class="icon_profile"></i>
                        <span>My Account</span>
                        <span class="menu-arrow arrow_carrot-right"></span>
                    </a>
                    <ul class="sub">
                        <li><a class="" href="admin_profile.php">My Profile</a></li>
                    </ul>
                </li>

            </ul>
            <!-- sidebar menu end-->
        </div>
    </aside>
    <!--sidebar end-->

    <!--main content start-->
    <section id="main-content">
        <section class="wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <h3 class="page-header"><i class="fa fa-user-md"></i> Device record section</h3>
                    <ol class="breadcrumb">
                        <li><i class="fa fa-home"></i><a href="index.php">Home</a></li>
                        <li><i class="fa fa-mobile-phone"></i>Device Record</li>
                    </ol>
                </div>
            </div>
            <!-- page start-->
            <div class="row">
                <div class="col-lg-12">
                    <section class="panel">
                        <header class="panel-heading tab-bg-info">
                            <ul class="nav nav-tabs">
                                <!--<li class="active">
                                    <a data-toggle="tab" href="#recent-activity">
                                        <i class="icon-home"></i>
                                        Daily Activity
                                    </a>
                                </li>-->
                                <li>
                                    <a data-toggle="tab" href="#enquiries">
                                        <i class="icon-user"></i>
                                        View Enquiries
                                    </a>
                                </li>
                                <li class="">
                                    <a data-toggle="tab" href="#new-device">
                                        <i class="icon-envelope"></i>
                                        Book device
                                    </a>
                                </li>
                                <li class="">
                                    <a data-toggle="tab" href="#recorded-devices">
                                        <i class="icon-envelope"></i>
                                        Booked devices
                                    </a>
                                </li>
                            </ul>
                        </header>
                        <div class="panel-body">
                            <div class="tab-content">
                                <!-- profile -->
                                <div id="enquiries" class="tab-pane active">
                                    <section class="panel">
                                        <div class="panel-body bio-graph-info">
                                            <h1>List of enquiries</h1>
                                            <table class="table table-striped table-advance table-hover">
                                                <tbody>
                                                <tr>
                                                    <th><i class="icon_profile"></i>Full Name</th>
                                                    <th><i class="icon_mail"></i> Email</th>
                                                    <th><i class="icon_phone"></i> Contact</th>
                                                    <th><i class="icon_mobile"></i> Device Name</th>
                                                    <th><i class="icon_cursor"></i>Serial</th>
                                                    <th><i class="icon_question"></i>Problem</th>
                                                    <th><i class="icon_calendar"></i>Date</th>
                                                    <th><i class="icon_cogs"></i>Action</th>
                                                </tr>
                                                <tr>
                                                    <?php

                                                    $query="SELECT * FROM enquiry ORDER BY equiry_id DESC ";
                                                    //var_dump($query3);die();
                                                    $res = $pdo->query($query);
                                                    if($res->rowCount() > 0){
                                                    while($row = $res->fetch()){
                                                    $id=$row['enquiry_number'];
                                                    $equiry=$row['equiry_id'];
                                                    //$id=$row['user_id'];
                                                    //var_dump($row);die();

                                                    ?>
                                                    <td><?php echo $row['unames']; ?></td>
                                                    <td><?php echo $row['email']; ?></td>
                                                    <td>0<?php echo $row['contact']; ?></td>
                                                    <td><?php echo $row['device_name']; ?></td>
                                                    <td><?php echo $row['model']; ?></td>
                                                    <td><?php echo $row['problem']; ?></td>
                                                    <td><?php echo $row['enquiry_date']; ?></td>
                                                    <td><div class="btn-group">
                                                            <a class="btn btn-primary" href="record_enquired_device.php?enquiry_number=<?php echo $id; ?>" onclick='return confirm("Are you sure you want to create a job card for this device?")'><i class="icon_check_alt2"></i>Create</a>
                                                        </div>
                                                    </td>
                                                </tr>
                                                <?php
                                                }
                                                }
                                                else{
                                                    echo '<script language="javascript">';
                                                    echo 'alert("No records matching your account were found")';
                                                    echo '</script>';

                                                }

                                                ?>
                                                </tbody>
                                            </table>
                                        </div>
                                    </section>
                                    <section>
                                        <div class="row">
                                        </div>
                                    </section>
                                </div>
                                <!-- edit-profile -->
                                <div id="new-device" class="tab-pane">
                                    <section class="panel">
                                        <div class="panel-body bio-graph-info">
                                            <h1>Device repair booking</h1>
                                            <form class="form-horizontal" method="post" role="form">
                                                <div class="form-group">
                                                    <label class="col-lg-2 control-label">Client Name</label>
                                                    <div class="col-lg-6">
                                                        <input type="text" class="form-control" name="client_name" required id="f-name" placeholder="Enter Client Name ">
                                                    </div>
                                                </div>
                                                <div class="form-group">
                                                    <label class="col-lg-2 control-label">Email</label>
                                                    <div class="col-lg-6">
                                                        <input type="email" class="form-control" name="email" required id="l-name" placeholder=" ">
                                                    </div>
                                                </div>
                                                <div class="form-group">
                                                    <label class="col-lg-2 control-label">Contact Number</label>
                                                    <div class="col-lg-6">
                                                        <input type="number" name="contact" required class="form-control" id="b-day" placeholder="">
                                                    </div>
                                                </div>
                                                <div class="form-group">
                                                    <label class="col-lg-2 control-label">Device Name</label>
                                                    <div class="col-lg-6">
                                                        <input type="text" name="device_name" required class="form-control" id="email" placeholder=" ">
                                                    </div>
                                                </div>
                                                <div class="form-group">
                                                    <label class="col-lg-2 control-label">Serial Number</label>
                                                    <div class="col-lg-6">
                                                        <input type="text" name="serial" required class="form-control" id="mobile" placeholder=" ">
                                                    </div>
                                                </div>
                                                <div class="form-group">
                                                    <label class="col-lg-2 control-label">Notes</label>
                                                    <div class="col-lg-6">
                                                        <textarea type="text" name="notes"  class="form-control"  placeholder=""></textarea>
                                                    </div>
                                                </div>
                                                <div class="form-group">
                                                    <label class="control-label col-lg-2">Assign Technician</label>
                                                    <div class="col-lg-6">
                                                        <input type="text" name="tech"  required class="form-control" id="mobile" placeholder=" ">
                                                    </div>
                                                </div>
                                                <div class="form-group">
                                                    <label class="col-lg-2 control-label">Amount Due</label>
                                                    <div class="col-lg-6">
                                                        <input type="number" name="amount" value="0.00" class="form-control"  placeholder="0.00">
                                                    </div>
                                                </div>
                                                <div class="form-group">
                                                    <label class="control-label col-lg-2" for="inputSuccess">Visible Marks</label>
                                                    <div class="col-lg-10">
                                                        <label class="checkbox-inline">Dent <input type="checkbox" name="dent" id="inlineCheckbox1" value="dent">
                                                        </label>
                                                        <label class="checkbox-inline">Charger<input type="checkbox" name="charger" id="inlineCheckbox2" value="charger">
                                                        </label>
                                                        <label class="checkbox-inline"> Screws/Feet  <input type="checkbox" name="screws" id="inlineCheckbox3" value="screws">
                                                        </label>
                                                        <label class="checkbox-inline"> HDD/SSD <input type="checkbox" name="ssd" id="inlineCheckbox3" value="ssd/hdd">
                                                        </label>

                                                    </div>
                                                </div>
                                                <div class="form-group">
                                                    <label class="control-label col-lg-2" for="inputSuccess">Strains</label>
                                                    <div class="col-lg-10">
                                                        <label class="checkbox-inline">Rust <input type="checkbox" name="rust" id="inlineCheckbox1" value="rust">
                                                        </label>
                                                        <label class="checkbox-inline">Back Cover<input type="checkbox" name="cover" id="inlineCheckbox2" value="cover">
                                                        </label>
                                                        <label class="checkbox-inline"> Hinge  <input type="checkbox" name="hinge" id="inlineCheckbox3" value="hinge">
                                                        </label>
                                                        <label class="checkbox-inline"> RAM <input type="checkbox" name="ram" id="inlineCheckbox3" value="ram" >
                                                        </label>

                                                    </div>
                                                </div>
                                                <div class="form-group">
                                                    <div class="col-lg-offset-2 col-lg-10">
                                                        <button type="submit" name="book" class="btn btn-primary">Book</button>
                                                        <button type="button" class="btn btn-danger">Cancel</button>
                                                    </div>
                                                </div>
                                            </form>
                                            <?php
                                            if(isset($_POST['book'])){
                                                $num1='';
                                                $num2='';
                                                $year = date("Y");
                                                $num1 = (rand(0,9));
                                                $num2 = (rand(0,9));
                                                function generateCode($numchars=5,/*$digits=1,*/$letters=1)
                                                {
                                                    $dig = "012345678923456789";
                                                    $abc = "ABCDEFGHJKLMNOPQRSTUVWXYZ";
                                                    if($letters == 1)
                                                    {
                                                        $str = $abc;
                                                    }

                                                    for($i=0; $i < $numchars; $i++)
                                                    {
                                                        $randomized = $str{rand() % strlen($str)};
                                                    }
                                                    return $randomized;
                                                }

                                                $code = generateCode('5','1');
                                                $id= "KEL". $year . $num1 .$num2 .$code;
                                                $name =$_POST['client_name'];
                                                $mail =$_POST['email'];
                                                $cont=$_POST['contact'];
                                                $device=$_POST['device_name'];
                                                $serial=$_POST['serial'];
                                                $notes=$_POST['notes'];
                                                $tech=$_POST['tech'];
                                                $amt=$_POST['amount'];
                                                $dent=$_POST['dent'];
                                                $chr =$_POST['charger'];
                                                $scr=$_POST['screws'];
                                                $ssd=$_POST['ssd'];
                                                $rust=$_POST['rust'];
                                                $cvr=$_POST['cover'];
                                                $hng=$_POST['hinge'];
                                                $ram=$_POST['ram'];
                                                try{
                                                    $ins = "INSERT INTO device_records(client_name, email, contact, device_name, serial, notes, tech, amount, dent, charger, screws, ssd, rust, cover, hinge, ram, record_number, record_date) 
VALUES ('$name', '$mail', '$cont', '$device', '$serial', '$notes', '$tech', '$amt', '$dent', '$chr', '$scr', '$ssd', '$rust', '$cvr', '$hng', '$ram', '$id', CURRENT_DATE )";
                                                    $pdo->exec($ins);
                                                    echo '<script language="javascript">';
                                                    echo 'alert("Device recorded successfully")';
                                                    echo '</script>';

                                                }
                                                catch(PDOException $e){
                                                    die("ERROR: Could not able to execute $ins. " . $e->getMessage());
                                                }
                                                if ($ins) {
                                                    $to = $_POST['email'];
                                                    $subject = 'Job Card';
                                                    $message = 'Good Day, 
I hope you are well. 

Thank you for your interest in our service offering. Please go to www.keltechrepairs.co.za/system and login into your account to view the job card.

For any further queries, contact us on 021-824 6261

DIRECT PAYMENTS TO: KELTECH REPAIRS

STANDARD BANK CHEQUE ACCOUNT # 070 616 396, BRANCH CODE 020909.

Would you like to stay up to date with the latest news and promotions from Keltech Repairs? Do not 
forget to like us on https://www.facebook.com/keltechrepair

kind regards,

Keltech Repairs
                                                    ';
                                                    $from = 'info@keltechrepairs.co.za';
                                                    // Sending email
                                                    if (mail($to, $subject, $message)) {
                                                        echo '<script language="javascript">';
                                                        echo 'alert("Your mail has been sent successfully.")';
                                                        echo '</script>';
                                                    }
                                                } else {
                                                    echo 'Email not sent';
                                                }
                                                }
                                            ?>
                                        </div>
                                    </section>
                                </div>
                                <div id="recorded-devices" class="tab-pane">
                                    <section class="panel">
                                        <div class="panel-body bio-graph-info">
                                            <h1> Booked Devices </h1>
                                            <table class="table table-striped table-advance table-hover">
                                                <tbody>
                                                <tr>
                                                    <th><i class="icon_profile"></i>Client Name</th>
                                                    <th><i class="icon_mail"></i> Email</th>
                                                    <th><i class="icon_phone"></i> Contact</th>
                                                    <th><i class="icon_mobile"></i> Device Name</th>
                                                    <th><i class="icon_cursor"></i>Serial</th>
                                                    <th><i class="icon_question"></i>Problem</th>
                                                    <th><i class="icon_profile"></i>Technician</th>
                                                    <th><i class="icon_calendar"></i>Date</th>
                                                    <th><i class="icon_cogs"></i>Action</th>
                                                </tr>
                                                <tr>
                                                    <?php
                                                    //$id=$_GET['record_number'];
                                                    $qry="SELECT * FROM device_records ORDER BY record_id DESC ";
                                                    //var_dump($query3);die();
                                                    $res = $pdo->query($qry);
                                                    if($res->rowCount() > 0){
                                                    while($row = $res->fetch()){
                                                    $id=$row['record_number'];
                                                    $equiry=$row['record_id'];
                                                    //$id=$row['user_id'];
                                                    //var_dump($row);die();

                                                    ?>
                                                    <td><?php echo $row['client_name']; ?></td>
                                                    <td><?php echo $row['email']; ?></td>
                                                    <td>0<?php echo $row['contact']; ?></td>
                                                    <td><?php echo $row['device_name']; ?></td>
                                                    <td><?php echo $row['serial']; ?></td>
                                                    <td><?php echo $row['notes']; ?></td>
                                                    <td><?php echo $row['tech']; ?></td>
                                                    <td><?php echo $row['record_date']; ?></td>
                                                    <td><div class="btn-group">
                                                            <a class="btn btn-primary" href="booking_detail.php?record_number=<?php echo $id; ?>" onclick='return confirm("Are you sure you want to view device details?")'><i class="icon_check_alt2"></i>View</a>
                                                        </div>
                                                    </td>
                                                </tr>
                                                <?php
                                                }
                                                }
                                                else{
                                                    echo '<script language="javascript">';
                                                    echo 'alert("No records matching your account were found")';
                                                    echo '</script>';

                                                }

                                                ?>
                                                </tbody>
                                            </table>
                                        </div>
                                    </section>
                                </div>


                            </div>
                        </div>

                        <!-- page end-->
                    </section>
        </section>
        <!--main content end-->
        <div class="text-center">
            <div class="credits">
                <!--
                  All the links in the footer should remain intact.
                  You can delete the links only if you purchased the pro version.
                  Licensing information: https://bootstrapmade.com/license/
                  Purchase the pro version form: https://bootstrapmade.com/buy/?theme=NiceAdmin
                -->
                <a href="#">Copyright @ Keltech Repairs 2017</a>
            </div>
        </div>
    </section>
    <!-- container section end -->
    <!-- javascripts -->
    <script src="../js/jquery.js"></script>
    <script src="../js/bootstrap.min.js"></script>
    <!-- nice scroll -->
    <script src="../js/jquery.scrollTo.min.js"></script>
    <script src="../js/jquery.nicescroll.js" type="text/javascript"></script>
    <!-- jquery knob -->
    <script src="../assets/jquery-knob/js/jquery.knob.js"></script>
    <!--custome script for all page-->
    <script src="../js/scripts.js"></script>

    <script>
        //knob
        $(".knob").knob();
    </script>


</body>

</html>
