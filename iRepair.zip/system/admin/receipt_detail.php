<?php
session_start();
include("../dbcon.php");
$user=$_SESSION['username'];
$sql = "select * from users where username = '$user' ";
$result = $pdo->query($sql);
$row = $result->fetch();

$FirstName=$row['first_name'];
$LastName=$row['last_name'];
$username=$row['username'];
$mail=$row['email'];
$gender=$row['gender'];
$phone=$row['phone'];
$adr=$row['address'];
$acc=$row['design'];
$role=$row['role'];
if(!$user){
    header("location: ../index.php");
    echo "document expired";
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Keltech Repairs">
    <meta name="author" content="Keltech Repairs">
    <meta name="keyword" content="keltech repairs">
    <link rel="shortcut icon" href="img/favicon.png">

    <title>Keltech Repairs</title>

    <!-- Bootstrap CSS -->
    <link href="../css/bootstrap.min.css" rel="stylesheet">
    <!-- bootstrap theme -->
    <link href="../css/bootstrap-theme.css" rel="stylesheet">
    <!--external css-->
    <!-- font icon -->
    <link href="../css/elegant-icons-style.css" rel="stylesheet" />
    <link href="../css/font-awesome.min.css" rel="stylesheet" />
    <!-- Custom styles -->
    <link href="../css/style.css" rel="stylesheet">
    <link href="../css/style-responsive.css" rel="stylesheet" />

    <!-- HTML5 shim and Respond.js IE8 support of HTML5 -->
    <!--[if lt IE 9]>
    <script src="../js/html5shiv.js"></script>
    <script src="js/respond.min.js"></script>
    <script src="../js/lte-ie7.js"></script>
    <![endif]-->
</head>

<body>
<!-- container section start -->
<section id="container" class="">

    <header class="header dark-bg">
        <div class="toggle-nav">
            <div class="icon-reorder tooltips" data-original-title="Toggle Navigation" data-placement="bottom"><i class="icon_menu"></i></div>
        </div>

        <!--logo start-->
        <a href="index.php" class="logo"><img src="../img/keltechlogo.png" class="img-rounded" style="width: 10%"> <span class="lite">Keltech Repairs</span></a>
        <!--logo end-->

        <div class="nav search-row" id="top_menu">
            <!--  search form start --
            <ul class="nav top-menu">
                <li>
                    <form class="navbar-form">
                        <input class="form-control" placeholder="Search" type="text">
                    </form>
                </li>
            </ul>
            <!--  search form end -->
        </div>

        <div class="top-nav notification-row">
            <!-- notificatoin dropdown start-->
            <ul class="nav pull-right top-menu">

                <li class="dropdown">
                    <a data-toggle="dropdown" class="dropdown-toggle" href="#">
                            <span class="profile-ava">
                                <i class="icon_profile"></i>
                            </span>
                        <span class="username"><?php echo $FirstName." ". $LastName; ?></span>
                        <b class="caret"></b>
                    </a>
                    <ul class="dropdown-menu extended logout">
                        <div class="log-arrow-up"></div>
                        <li class="eborder-top">
                            <a href="admin_profile.php"><i class="icon_profile"></i> My Profile</a>
                        </li>
                        <li>
                            <a href="#"><i class="icon_mail_alt"></i> My Inbox</a>
                        </li>
                        <li>
                            <!--<a href="#"><i class="icon_clock_alt"></i> Timeline</a>-->
                        </li>
                        <li>
                            <a href="#"><i class="icon_chat_alt"></i> Chats</a>
                        </li>
                        <li>
                            <a href="../logout.php"><i class="icon_key_alt"></i> Log Out</a>
                        </li>
                        <li>
                            <!-- <a href="documentation.html"><i class="icon_key_alt"></i> Documentation</a>
                           </li>
                           <li>
                             <a href="documentation.html"><i class="icon_key_alt"></i> Documentation</a>-->
                        </li>
                    </ul>
                </li>
                <!-- user login dropdown end -->
            </ul>
            <!-- notificatoin dropdown end-->
        </div>
    </header>
    <!--header end-->

    <!--sidebar start-->
    <aside>
        <div id="sidebar" class="nav-collapse ">
            <!-- sidebar menu start-->
            <ul class="sidebar-menu">
                <li class="active">
                    <a class="" href="index.php">
                        <i class="icon_house_alt"></i>
                        <span>Home</span>
                    </a>
                </li>
                <li class="sub-menu">
                    <a href="javascript:;" class="">
                        <i class="icon_laptop"></i>
                        <span>Devices</span>
                        <span class="menu-arrow arrow_carrot-right"></span>
                    </a>
                    <ul class="sub">
                        <li><a class="" href="record_device.php">Record Devices</a></li>
                    </ul>
                </li>
                <li class="sub-menu">
                    <a href="javascript:;" class="">
                        <i class="icon_book_alt"></i>
                        <span>Accounts</span>
                        <span class="menu-arrow arrow_carrot-right"></span>
                    </a>
                    <ul class="sub">
                        <li><a class="" href="invoices.php">Create Invoices</a></li>
                        <li><a class="" href="quotation.php">Create Quotations</a></li>
                        <li><a class="" href="receipts.php">Receipts</a></li>
                        <li><a class="" href="stock_take.php">Record Stocks</a></li>
                    </ul>
                </li>
                <li class="sub-menu">
                    <a href="javascript:;" class="">
                        <i class="icon_book_alt"></i>
                        <span>User accounts</span>
                        <span class="menu-arrow arrow_carrot-right"></span>
                    </a>
                    <ul class="sub">
                        <li><a class="" href="create_user.php">Create users</a></li>
                        <li><a class="" href="view_users.php">View Users</a></li>
                    </ul>
                </li>
                <li class="sub-menu">
                    <a href="javascript:;" class="">
                        <i class="icon_profile"></i>
                        <span>My Account</span>
                        <span class="menu-arrow arrow_carrot-right"></span>
                    </a>
                    <ul class="sub">
                        <li><a class="" href=admin_profile.php">My Profile</a></li>
                    </ul>
                </li>

            </ul>
            <!-- sidebar menu end-->
        </div>
    </aside>
    <!--sidebar end-->

    <!--main content start-->
    <section id="main-content">
        <section class="wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <h3 class="page-header"><i class="fa fa-user-md"></i>Receipts section</h3>
                    <ol class="breadcrumb">
                        <li><i class="fa fa-home"></i><a href="index.php">Home</a></li>
                        <li><i class="fa fa-mobile-phone"></i>Cash Receipt</li>
                    </ol>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-12">
                    <section class="panel">
                        <div id="edit-profile" class="tab-pane">
                            <section class="panel">
                                <div class="panel-body bio-graph-info">
                                    <h1> <a class="pull-right btn btn-primary" href="javascript:void(0);" onclick="print();">Print</a> <a class="pull-right btn btn-primary" href="receipts.php"><i class="icon_refresh"></i> Back</a></h1>
                                    <?php
                                    $id=$_GET['receipt_number'];
                                    $query="SELECT * FROM receipts WHERE receipt_number='$id'";
                                    //var_dump($query3);die();
                                    $res = $pdo->query($query);
                                    while($row = $res->fetch()) {
                                    $rec = $row['receipt_number'];
                                    $first = $row['client_name'];
                                    $rep = $row['sales_rep'];
                                    $amnt = $row['amount'];
                                    $rec = $row['received'];
                                    $bal = $row['balance'];
                                    $dsc = $row['description'];
                                    $date=$row['receipt_date'];
                                    $number=$row['receipt_number'];
                                    $due=$row['due_date'];
                                    ?>
                                    <div id="print">
                                    <div class="row">
                                        <h1 class="text-left"></h1>
                                        <div class="col-md-4 text-left">

                                            <p><img src="../img/keltechlogo.png" class="img-rounded" style="width: 20%"><br>Keltech Repairs (PVT) LTD<br>
                                                TAX No: 9591824165<br>
                                                REG: 2013/151506/07    	<br>
                                                </p>
                                        </div>
                                        <div class="col-md-4"></div>
                                        <div class="col-md-4">

                                            <h1 align="left"><strong>Keltech Repairs</strong></h1>
                                            <p align="left"> 2 Roeland Street<br>
                                                Ruskin House, Cape Town<br>
                                                Tel 021 461 4833 • 021 824 6261<br>
                                                www.keltechrepairs.co.za<br>
                                                info@keltechrepairs.co.za
                                            </p>
                                        </div></div>
                                        <div class="line"></div>
                                        <?php } ?>
                                    </div>
                                    <div class="row">
                                        <h1 align="center">CASH RECEIPT</h1>
                                        <div class="col-lg-12">
                                            <table class="table table-striped table-advance table-hover" border="1">
                                                <tbody>
                                                <tr>
                                                    <th>CLIENT</th>
                                                    <th>CONTACT NUMBER</th>
                                                    <th> EMAIL</th>
                                                </tr>
                                                <tr>
                                                    <?php
                                                    $id=$_GET['receipt_number'];
                                                    $query="SELECT * FROM receipts WHERE receipt_number='$id'";
                                                    //var_dump($query3);die();
                                                    $res = $pdo->query($query);
                                                    while($row = $res->fetch()) {
                                                    $record = $row['receipt_number'];
                                                    $first = $row['client_name'];
                                                    $cont = $row['contact'];
                                                    $mails = $row['email'];

                                                    ?>
                                                    <td><?php echo $first; ?></td>
                                                    <td><?php echo $cont; ?></td>
                                                    <td><?php echo $mails; ?></td>

                                                </tr>
                                                <?php

                                                }

                                                ?><br>
                                                <tr>
                                                    <th> DEVICE DESCRIPTION</th>
                                                    <th> SERIAL NUMBER</th>
                                                </tr>
                                                <tr>
                                                <?php
                                                $id=$_GET['receipt_number'];
                                                $query="SELECT * FROM receipts WHERE receipt_number='$id'";
                                                //var_dump($query3);die();
                                                $res = $pdo->query($query);
                                                while($row = $res->fetch()) {
                                                    $record = $row['receipt_number'];
                                                    $disc = $row['description'];
                                                    $ser = $row['serial'];

                                                    ?>
                                                    <td><?php echo $disc; ?></td>
                                                    <td><?php echo $ser; ?></td>
                                                    </tr>
                                                    <?php

                                                }

                                                ?><br>
                                                <tr>
                                                    <th>AMOUNT DUE</th>
                                                    <th>AMOUNT RECEIVED</th>
                                                    <th>TOTAL AMOUNT</th>
                                                </tr>
                                                <tr>
                                                    <?php
                                                    $id=$_GET['receipt_number'];
                                                    $query="SELECT * FROM receipts WHERE receipt_number='$id'";
                                                    //var_dump($query3);die();
                                                    $res = $pdo->query($query);
                                                    while($row = $res->fetch()) {
                                                    //$record = $row['record_number'];
                                                    $amt = $row['amount'];
                                                    $rece = $row['received'];
                                                    $amnt = $row['amount'];

                                                    ?>
                                                    <td>R <?php echo $amt; ?>.00</td>
                                                    <td>R <?php echo $rece; ?>.00</td>
                                                    <td>R <?php echo $amnt; ?>.00</td>

                                                </tr>
                                                <?php

                                                }

                                                ?>

                                                </tbody>


                                            </table>
                                        </div>
                                    </div>

                                    <div class="row">
                                        <div class="col-md-12">
                                            <p>
                                                DIRECT DEPOSITS TO: KELTECH REPAIRS<br>
                                                STANDARD BANK CHEQUE ACCOUNT # 070 616 396 BRANCH CODE 020909<br>
                                            </p>
                                        </div>
                                        <div class="col-md-1"></div>
                                        <div class="col-md-8">
                                            <h6>TERMS AND CONDITIONS</h6>
                                            <p> 1. All repairs, services and installations professionally done, in good faith: should you be dissatisfied, please notify us within 48 hours for correction. Failure to do so may result in additional costs being incurred.<br>
                                                2. Devices are booked in at the client’s risk. Keltech Repairs is not liable for any data loss or damage sustained during hardware or software repairs. <strong>PLEASE NOTE</strong> Your device may be restored or formatted to complete repair. Please back up your data beforehand.<br>
                                                3. Keltech Repairs cannot be held responsible for DIY installations on any accessories and parts sold separately.  <br>
                                                4. Replaced parts – apart from batteries and liquid-damaged devices– have a 6-month warrantee that excludes any damage caused by negligence (eg devices that are dropped) or tampering.<br>
                                                5. Liquid damaged devices: only parts replaced as per invoice are guaranteed, for 3 months.<br>
                                                6. Warranties are not transferable.<br>
                                                7. Devices not collected within 31 days of notification may be sold to defray costs.<br>
                                                8. The use of generic charges voids your warrantee on logic board repairs.</p>
                                        </div><div class="col-md-1"></div></div>
                                        <div class="row"><div class="line"></div>
                                        <div class="col-sm-12">
                                            <h3 align="center">THANK YOU FOR YOUR CUSTOM!<br> PLEASE LIKE US ON FACEBOOK AND REFER US TO YOUR FRIENDS</h3>
                                            <p align="center">https://www.facebook.com/keltechrepair/</p>
                                        </div>
                                </div>
                                </div>

                            </section>
                        </div>
                    </section>
                </div>
            </div>

            <!-- page end-->
        </section>
    </section>
    <!--main content end-->
    <div class="text-center">
        <div class="credits">
            <!--
              All the links in the footer should remain intact.
              You can delete the links only if you purchased the pro version.
              Licensing information: https://bootstrapmade.com/license/
              Purchase the pro version form: https://bootstrapmade.com/buy/?theme=NiceAdmin
            -->
            <a href="#">Copyright @ Keltech Repairs 2017</a>
        </div>
    </div>
</section>
<!-- container section end -->
<!-- javascripts -->
<script src="../js/jquery.js"></script>
<script src="../js/bootstrap.min.js"></script>
<!-- nice scroll -->
<script src="../js/jquery.scrollTo.min.js"></script>
<script src="../js/jquery.nicescroll.js" type="text/javascript"></script>
<!-- jquery knob -->
<script src="../assets/jquery-knob/js/jquery.knob.js"></script>
<!--custome script for all page-->
<script src="../js/scripts.js"></script>

<script>
    //knob
    $(".knob").knob();
</script>


<script type="text/javascript">
    function print() {
        var data = '<input type="button" value="Print" onClick="window.print()">';
        var DocumentContainer = document.getElementById('print');
        //data += $('printlayoutable').html();
        //data += '</div>';
        var WindowObject = window.open('', "TrackHistoryData",
            "width=740,height=325,top=200,left=250,toolbars=no,scrollbars=yes,status=no,resizable=no");
        WindowObject.document.writeln(DocumentContainer.innerHTML);
        //WindowObject.document.writeln(DocumentContainer.innerHTML);
        WindowObject.document.close();
        WindowObject.focus();
        WindowObject.print();
        WindowObject.close();
</script>

</body>

</html>
