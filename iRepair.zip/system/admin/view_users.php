<?php
session_start();
include("../dbcon.php");
$user=$_SESSION['username'];
$sql = "select * from users where username = '$user' ";
$result = $pdo->query($sql);
$row = $result->fetch();

$FirstName=$row['first_name'];
$LastName=$row['last_name'];
$username=$row['username'];
$mail=$row['email'];
$gender=$row['gender'];
$phone=$row['phone'];
$adr=$row['address'];
$acc=$row['design'];
$role=$row['role'];
if(!$user){
    header("location: ../index.php");
    echo "document expired";
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Keltech Repairs">
    <meta name="author" content="Keltech Repairs">
    <meta name="keyword" content="keltech repairs">
    <link rel="shortcut icon" href="img/favicon.png">

    <title>Keltech Repairs</title>

    <!-- Bootstrap CSS -->
    <link href="../css/bootstrap.min.css" rel="stylesheet">
    <!-- bootstrap theme -->
    <link href="../css/bootstrap-theme.css" rel="stylesheet">
    <!--external css-->
    <!-- font icon -->
    <link href="../css/elegant-icons-style.css" rel="stylesheet" />
    <link href="../css/font-awesome.min.css" rel="stylesheet" />
    <!-- Custom styles -->
    <link href="../css/style.css" rel="stylesheet">
    <link href="../css/style-responsive.css" rel="stylesheet" />

    <!-- HTML5 shim and Respond.js IE8 support of HTML5 -->
    <!--[if lt IE 9]>
    <script src="../js/html5shiv.js"></script>
    <script src="js/respond.min.js"></script>
    <script src="../js/lte-ie7.js"></script>
    <![endif]-->


</head>

<body>
<!-- container section start -->
<section id="container" class="">


    <header class="header dark-bg">
        <div class="toggle-nav">
            <div class="icon-reorder tooltips" data-original-title="Toggle Navigation" data-placement="bottom"><i class="icon_menu"></i></div>
        </div>

        <!--logo start-->
        <a href="index.php" class="logo"><img src="../img/keltechlogo.png" class="img-rounded" style="width: 10%"> <span class="lite">Keltech Repairs</span></a>
        <!--logo end-->

        <div class="nav search-row" id="top_menu">
            <!--  search form start --
            <ul class="nav top-menu">
                <li>
                    <form class="navbar-form">
                        <input class="form-control" placeholder="Search" type="text">
                    </form>
                </li>
            </ul>
            <!--  search form end -->
        </div>

        <div class="top-nav notification-row">
            <!-- notificatoin dropdown start-->
            <ul class="nav pull-right top-menu">
                <!-- alert notification end-->
                <!-- user login dropdown start-->
                <li class="dropdown">
                    <a data-toggle="dropdown" class="dropdown-toggle" href="#">
                            <span class="profile-ava">
                                <i class="icon_profile"></i>
                            </span>
                        <span class="username"><?php echo $FirstName." ". $LastName; ?></span>
                        <b class="caret"></b>
                    </a>
                    <ul class="dropdown-menu extended logout">
                        <div class="log-arrow-up"></div>
                        <li class="eborder-top">
                            <a href="admin_profile.php"><i class="icon_profile"></i> My Profile</a>
                        </li>
                        <li>
                            <a href="#"><i class="icon_mail_alt"></i> My Inbox</a>
                        </li>
                        <li>
                            <!--<a href="#"><i class="icon_clock_alt"></i> Timeline</a>-->
                        </li>
                        <li>
                            <a href="#"><i class="icon_chat_alt"></i> Chats</a>
                        </li>
                        <li>
                            <a href="../logout.php"><i class="icon_key_alt"></i> Log Out</a>
                        </li>
                        <li>
                            <!-- <a href="documentation.html"><i class="icon_key_alt"></i> Documentation</a>
                           </li>
                           <li>
                             <a href="documentation.html"><i class="icon_key_alt"></i> Documentation</a>-->
                        </li>
                    </ul>
                </li>
                <!-- user login dropdown end -->
            </ul>
            <!-- notificatoin dropdown end-->
        </div>
    </header>
    <!--header end-->

    <!--sidebar start-->
    <aside>
        <div id="sidebar" class="nav-collapse ">
            <!-- sidebar menu start-->
            <ul class="sidebar-menu">
                <li class="active">
                    <a class="" href="index.php">
                        <i class="icon_house_alt"></i>
                        <span>Home</span>
                    </a>
                </li>
                <li class="sub-menu">
                    <a href="javascript:;" class="">
                        <i class="icon_laptop"></i>
                        <span>Devices</span>
                        <span class="menu-arrow arrow_carrot-right"></span>
                    </a>
                    <ul class="sub">
                        <li><a class="" href="record_device.php">Record Devices</a></li>
                    </ul>
                </li>
                <li class="sub-menu">
                    <a href="javascript:;" class="">
                        <i class="icon_book_alt"></i>
                        <span>Accounts</span>
                        <span class="menu-arrow arrow_carrot-right"></span>
                    </a>
                    <ul class="sub">
                        <li><a class="" href="invoices.php">Create Invoices</a></li>
                        <li><a class="" href="quotation.php">Create Quotations</a></li>
                        <li><a class="" href="receipts.php">Receipts</a></li>
                        <li><a class="" href="stock_take.php">Record Stocks</a></li>
                    </ul>
                </li>
                <li class="sub-menu">
                    <a href="javascript:;" class="">
                        <i class="icon_book_alt"></i>
                        <span>User accounts</span>
                        <span class="menu-arrow arrow_carrot-right"></span>
                    </a>
                    <ul class="sub">
                        <li><a class="" href="create_user.php">Create users</a></li>
                        <li><a class="" href="view_users.php">View Users</a></li>
                    </ul>
                </li>

                <li class="sub-menu">
                    <a href="javascript:;" class="">
                        <i class="icon_profile"></i>
                        <span>My Account</span>
                        <span class="menu-arrow arrow_carrot-right"></span>
                    </a>
                    <ul class="sub">
                        <li><a class="" href="admin_profile.php">My Profile</a></li>
                    </ul>
                </li>

            </ul>
            <!-- sidebar menu end-->
        </div>
    </aside>
    <!--sidebar end-->

    <!--main content start-->
    <section id="main-content">
        <section class="wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <h3 class="page-header"><i class="fa fa-user-md"></i>User section</h3>
                    <ol class="breadcrumb">
                        <li><i class="fa fa-home"></i><a href="index.php">Home</a></li>
                        <li><i class="fa fa-mobile-phone"></i>Create Users</li>
                    </ol>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-12">
                    <section class="panel">
                        <header class="panel-heading tab-bg-info">
                            <ul class="nav nav-tabs">
                                <!--<li class="active">
                                    <a data-toggle="tab" href="#recent-activity">
                                        <i class="icon-home"></i>
                                        Daily Activity
                                    </a>
                                </li>-->
                                <li>
                                    <a data-toggle="tab" href="#admin_user">
                                        <i class="icon-user"></i>
                                        Admin users
                                    </a>
                                </li>
                                <li class="">
                                    <a data-toggle="tab" href="#technician">
                                        <i class="icon-envelope"></i>
                                        Technicians
                                    </a>
                                </li>
                                <li class="">
                                    <a data-toggle="tab" href="#client">
                                        <i class="icon-envelope"></i>
                                        Clients
                                    </a>
                                </li>
                            </ul>
                        </header>
                        <div class="panel-body">
                            <div class="tab-content">
                                <div id="admin_user" class="tab-pane active">
                                    <section class="panel">
                                        <div class="panel-body bio-graph-info">
                                            <h1> Administrators </h1>
                                            <table class="table table-striped table-advance table-hover">
                                                <tbody>
                                                <tr>
                                                    <th><i class="icon_profile"></i>Name</th>
                                                    <th><i class="icon_profile"></i> Username</th>
                                                    <th><i class="icon_mail"></i>Email</th>
                                                    <th><i class="icon_mobile"></i> Contact</th>
                                                    <th><i class=""></i>Address</th>
                                                    <th><i class="icon_cogs"></i>Action</th>
                                                </tr>
                                                <tr>
                                                    <?php
                                                    //$id=$_GET['record_number'];
                                                    $qry="SELECT * FROM users WHERE role = 'admin' ORDER BY user_id DESC ";
                                                    //var_dump($query3);die();
                                                    $res = $pdo->query($qry);
                                                    if($res->rowCount() > 0){
                                                    while($row = $res->fetch()){
                                                    $id=$row['user_id'];
                                                    $name=$row['first_name'];
                                                    $surname=$row['last_name'];

                                                    ?>
                                                    <td><?php echo $name. " ".$surname; ?></td>
                                                    <td><?php echo $row['username']; ?></td>
                                                    <td><?php echo $row['email']; ?></td>
                                                    <td>0<?php echo $row['phone']; ?></td>
                                                    <td><?php echo $row['address']; ?></td>
                                                    <td><div class="btn-group">
                                                            <a class="btn btn-primary" href="delete_user.php?user_id=<?php echo $id; ?>" onclick='return confirm("Are you sure you want to delete user?")'><i class="icon_check_alt2"></i>Delete</a>
                                                        </div>
                                                    </td>
                                                </tr>
                                                <?php
                                                }
                                                }
                                                else{
                                                    echo '<script language="javascript">';
                                                    echo 'alert("No users were found")';
                                                    echo '</script>';

                                                }

                                                ?>
                                                </tbody>
                                            </table>
                                        </div>
                                    </section>
                                </div>
                                <div id="technician" class="tab-pane">
                                    <section class="panel">
                                        <div class="panel-body bio-graph-info">
                                            <h1> Technicians </h1>
                                            <table class="table table-striped table-advance table-hover">
                                                <tbody>
                                                <tr>
                                                    <th><i class="icon_profile"></i>Name</th>
                                                    <th><i class="icon_profile"></i> Username</th>
                                                    <th><i class="icon_mail"></i>Email</th>
                                                    <th><i class="icon_mobile"></i> Contact</th>
                                                    <th><i class=""></i>Address</th>
                                                    <th><i class="icon_cogs"></i>Action</th>
                                                </tr>
                                                <tr>
                                                    <?php
                                                    //$id=$_GET['record_number'];
                                                    $qry="SELECT * FROM users WHERE role = 'tech' ORDER BY user_id DESC ";
                                                    //var_dump($query3);die();
                                                    $res = $pdo->query($qry);
                                                    if($res->rowCount() > 0){
                                                    while($row = $res->fetch()){
                                                    $id=$row['user_id'];
                                                    $name=$row['first_name'];
                                                    $surname=$row['last_name'];

                                                    ?>
                                                    <td><?php echo $name. " ".$surname; ?></td>
                                                    <td><?php echo $row['username']; ?></td>
                                                    <td><?php echo $row['email']; ?></td>
                                                    <td>0<?php echo $row['phone']; ?></td>
                                                    <td><?php echo $row['address']; ?></td>
                                                    <td><div class="btn-group">
                                                            <a class="btn btn-primary" href="delete_user.php?user_id=<?php echo $id; ?>" onclick='return confirm("Are you sure you want to delete user?")'><i class="icon_check_alt2"></i>Delete</a>
                                                        </div>
                                                    </td>
                                                </tr>
                                                <?php
                                                }
                                                }
                                                else{
                                                    echo '<script language="javascript">';
                                                    echo 'alert("No users were found")';
                                                    echo '</script>';

                                                }

                                                ?>
                                                </tbody>
                                            </table>
                                        </div>
                                    </section>
                                </div>
                                <div id="client" class="tab-pane">
                                    <section class="panel">
                                        <div class="panel-body bio-graph-info">
                                            <h1> Clients </h1>
                                            <table class="table table-striped table-advance table-hover">
                                                <tbody>
                                                <tr>
                                                    <th><i class="icon_profile"></i>Name</th>
                                                    <th><i class="icon_profile"></i> Username</th>
                                                    <th><i class="icon_mail"></i>Email</th>
                                                    <th><i class="icon_mobile"></i> Contact</th>
                                                    <th><i class=""></i>Address</th>
                                                    <th><i class="icon_cogs"></i>Action</th>
                                                </tr>
                                                <tr>
                                                    <?php
                                                    //$id=$_GET['record_number'];
                                                    $qry="SELECT * FROM users WHERE role = 'Client' ORDER BY user_id DESC ";
                                                    //var_dump($query3);die();
                                                    $res = $pdo->query($qry);
                                                    if($res->rowCount() > 0){
                                                    while($row = $res->fetch()){
                                                    $id=$row['user_id'];
                                                    $name=$row['first_name'];
                                                    $surname=$row['last_name'];

                                                    ?>
                                                    <td><?php echo $name. " ".$surname; ?></td>
                                                    <td><?php echo $row['username']; ?></td>
                                                    <td><?php echo $row['email']; ?></td>
                                                    <td>0<?php echo $row['phone']; ?></td>
                                                    <td><?php echo $row['address']; ?></td>
                                                    <td><div class="btn-group">
                                                            <a class="btn btn-primary" href="delete_user.php?user_id=<?php echo $id; ?>" onclick='return confirm("Are you sure you want to delete user?")'><i class="icon_check_alt2"></i>Delete</a>
                                                        </div>
                                                    </td>
                                                </tr>
                                                <?php
                                                }
                                                }
                                                else{
                                                    echo '<script language="javascript">';
                                                    echo 'alert("No users were found")';
                                                    echo '</script>';

                                                }

                                                ?>
                                                </tbody>
                                            </table>
                                        </div>
                                    </section>
                                </div>
                            </div>
                        </div>

                        <!-- page end-->
                    </section>
        </section>
        <!--main content end-->
        <div class="text-center">
            <div class="credits">
                <!--
                  All the links in the footer should remain intact.
                  You can delete the links only if you purchased the pro version.
                  Licensing information: https://bootstrapmade.com/license/
                  Purchase the pro version form: https://bootstrapmade.com/buy/?theme=NiceAdmin
                -->
                <a href="#">Copyright @ Keltech Repairs 2017</a>
            </div>
        </div>
    </section>
    <!-- container section end -->
    <!-- javascripts -->
    <script src="../js/jquery.js"></script>
    <script src="../js/bootstrap.min.js"></script>
    <!-- nice scroll -->
    <script src="../js/jquery.scrollTo.min.js"></script>
    <script src="../js/jquery.nicescroll.js" type="text/javascript"></script>
    <!-- jquery knob -->
    <script src="../assets/jquery-knob/js/jquery.knob.js"></script>
    <!--custome script for all page-->
    <script src="../js/scripts.js"></script>

    <script>
        //knob
        $(".knob").knob();
    </script>


</body>

</html>
