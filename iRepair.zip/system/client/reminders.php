<?php
include("../dbcon.php");
$user=$_SESSION['username'];
$sql = "select * from users where username = '$user' ";
$result = $pdo->query($sql);
$row = $result->fetch();

$FirstName=$row['first_name'];
$LastName=$row['last_name'];
$username=$row['username'];
$mail=$row['email'];
$gender=$row['gender'];
$phone=$row['phone'];
$adr=$row['address'];
$acc=$row['design'];
$role=$row['role'];
if(!$user){
    header("location: ../index.php");
    echo "document expired";
}
$currentDate = date('Y-m-d'); //this will get the current date ie when this was posted 2107-07-06
$reminder = "SELECT * FROM quotations WHERE due= '$currentDate' "; //Sql query to find users that reminders dates match current date.
$result = $pdo->query($reminder);
if($run1 = $result->fetch())
{
    $rows = $run1->num_rows;

    for ($j = 0; $j < $rows; ++$j)//loop through each user in results and send a reminder email.
    {
        $run1->data_seek($j);
        $row = $run1->fetch_array(MYSQLI_NUM);

        $to = $mail; //gets the user email address
        $subject = "Reminder";
        $message = "Hi ".$FirstName."\nJust a reminder that your code 30 will expiry on the ".$row[6].",\n"
            ."Please renew your code\n"."\nThank You"."\nKeltech Repairs";
        $headers = "From: Keltech Repairs";

        mail($to,$subject,$message,$headers);
    }

}
?>