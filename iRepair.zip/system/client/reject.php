<?php
include('../dbcon.php');
$id=$_GET['quote_number'];

try {
    $ins = "UPDATE quotations SET status='reject' WHERE quote_number='$id'";
    $pdo->query($ins);
    //echo '<script language="javascript">';
    //echo 'alert("Thank you for your agreement")';
    //echo '</script>';
    header("location: client_quote.php");
} catch (PDOException $e) {
    die("ERROR: Could not able to execute $ins. " . $e->getMessage());
}