<?php
session_start();
include("../dbcon.php");
$user=$_SESSION['username'];
$sql = "select * from users where username = '$user' ";
$result = $pdo->query($sql);
$row = $result->fetch();

$FirstName=$row['first_name'];
$LastName=$row['last_name'];
$username=$row['username'];
$mail=$row['email'];
$gender=$row['gender'];
$phone=$row['phone'];
$adr=$row['address'];
$acc=$row['design'];
$role=$row['design'];
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Keltech Repairs">
    <meta name="author" content="Keltech Repairs">
    <meta name="keyword" content="keltech repairs">
    <link rel="shortcut icon" href="img/favicon.png">

    <title>Keltech Repairs</title>

    <!-- Bootstrap CSS -->
    <link href="../css/bootstrap.min.css" rel="stylesheet">
    <!-- bootstrap theme -->
    <link href="../css/bootstrap-theme.css" rel="stylesheet">
    <!--external css-->
    <!-- font icon -->
    <link href="../css/elegant-icons-style.css" rel="stylesheet" />
    <link href="../css/font-awesome.min.css" rel="stylesheet" />
    <!-- Custom styles -->
    <link href="../css/style.css" rel="stylesheet">
    <link href="../css/style-responsive.css" rel="stylesheet" />

    <!-- HTML5 shim and Respond.js IE8 support of HTML5 -->
    <!--[if lt IE 9]>
    <script src="../js/html5shiv.js"></script>
    <script src="js/respond.min.js"></script>
    <script src="../js/lte-ie7.js"></script>
    <![endif]-->

</head>

<body>
<!-- container section start -->
<section id="container" class="">


    <header class="header dark-bg">
        <div class="toggle-nav">
            <div class="icon-reorder tooltips" data-original-title="Toggle Navigation" data-placement="bottom"><i class="icon_menu"></i></div>
        </div>

        <!--logo start-->
        <a href="index.php" class="logo"><img src="../img/keltechlogo.png" class="img-rounded" style="width: 10%"> <span class="lite">Keltech Repairs</span></a>
        <!--logo end-->

        <div class="nav search-row" id="top_menu">
            <!--  search form start --
            <ul class="nav top-menu">
                <li>
                    <form class="navbar-form">
                        <input class="form-control" placeholder="Search" type="text">
                    </form>
                </li>
            </ul>
            <!--  search form end -->
        </div>

        <div class="top-nav notification-row">
            <!-- notificatoin dropdown start-->
            <ul class="nav pull-right top-menu">

                <!-- task notificatoin start -->
                <!-- alert notification end-->
                <!-- user login dropdown start-->
                <li class="dropdown">
                    <a data-toggle="dropdown" class="dropdown-toggle" href="#">
                            <span class="profile-ava">
                               <i class="icon_profile"></i>
                            </span>
                        <span class="username"><?php echo $FirstName." ". $LastName; ?></span>
                        <b class="caret"></b>
                    </a>
                    <ul class="dropdown-menu extended logout">
                        <div class="log-arrow-up"></div>
                        <li class="eborder-top">
                            <a href="tech_profile.php"><i class="icon_profile"></i> My Profile</a>
                        </li>
                        <li>
                            <a href="#"><i class="icon_mail_alt"></i> My Inbox</a>
                        </li>
                        <li>
                            <!--<a href="#"><i class="icon_clock_alt"></i> Timeline</a>-->
                        </li>
                        <li>
                            <a href="#"><i class="icon_chat_alt"></i> Chats</a>
                        </li>
                        <li>
                            <a href="../logout.php"><i class="icon_key_alt"></i> Log Out</a>
                        </li>
                        <li>
                            <!-- <a href="documentation.html"><i class="icon_key_alt"></i> Documentation</a>
                           </li>
                           <li>
                             <a href="documentation.html"><i class="icon_key_alt"></i> Documentation</a>-->
                        </li>
                    </ul>
                </li>
                <!-- user login dropdown end -->
            </ul>
            <!-- notificatoin dropdown end-->
        </div>
    </header>
    <!--header end-->

    <!--sidebar start-->
    <aside>
        <div id="sidebar" class="nav-collapse ">
            <!-- sidebar menu start-->
            <ul class="sidebar-menu">
                <li class="active">
                    <a class="" href="index.php">
                        <i class="icon_house_alt"></i>
                        <span>Home</span>
                    </a>
                </li>
                <li class="sub-menu">
                    <a href="javascript:;" class="">
                        <i class="icon_laptop"></i>
                        <span>Devices</span>
                        <span class="menu-arrow arrow_carrot-right"></span>
                    </a>
                    <ul class="sub">
                        <li><a class="" href="device_progress.php">Progress Update</a></li>
                        <li><a class="" href="job_cards.php">Job Cards</a></li>
                    </ul>
                </li>
                <li class="sub-menu">
                    <a href="javascript:;" class="">
                        <i class="icon_book_alt"></i>
                        <span>Accounts</span>
                        <span class="menu-arrow arrow_carrot-right"></span>
                    </a>
                    <ul class="sub">
                        <li><a class="" href="expenses.php">Record Expenses</a></li>
                    </ul>
                </li>

                <li class="sub-menu">
                    <a href="javascript:;" class="">
                        <i class="icon_profile"></i>
                        <span>My Account</span>
                        <span class="menu-arrow arrow_carrot-right"></span>
                    </a>
                    <ul class="sub">
                        <li><a class="" href="tech_profile.php">My Profile</a></li>
                    </ul>
                </li>

            </ul>
            <!-- sidebar menu end-->
        </div>
    </aside>
    <!--sidebar end-->

    <!--main content start-->
    <section id="main-content">
        <section class="wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <h3 class="page-header"><i class="fa fa-user-md"></i> Profile for <?php echo $FirstName; ?></h3>
                    <ol class="breadcrumb">
                        <li><i class="fa fa-home"></i><a href="index.php">Home</a></li>
                        <li><i class="fa fa-user-md"></i>Profile</li>
                    </ol>
                </div>
            </div>
            <div class="row">
                <!-- profile-widget -->
                <div class="col-lg-12">
                    <div class="profile-widget profile-widget-info">
                        <div class="panel-body">
                            <div class="col-lg-2 col-sm-2">
                                <h4><?php echo $FirstName." ". $LastName; ?></h4>
                                <div class="follow-ava">
                                    <i class="icon_profile"></i>
                                </div>
                                <h6><?php echo $role; ?></h6>
                            </div>
                            <div class="col-lg-2 col-sm-6 follow-info weather-category">
                                <!--<ul>
                                    <li class="active">

                                        <i class="fa fa-comments fa-2x"> </i><br> Contrary to popular belief, Lorem Ipsum is not simply
                                    </li>

                                </ul>
                            </div>
                            <div class="col-lg-2 col-sm-6 follow-info weather-category">
                                <ul>
                                    <li class="active">

                                        <i class="fa fa-bell fa-2x"> </i><br> Contrary to popular belief, Lorem Ipsum is not simply
                                    </li>

                                </ul>
                            </div>
                            <div class="col-lg-2 col-sm-6 follow-info weather-category">
                                <ul>
                                    <li class="active">

                                        <i class="fa fa-tachometer fa-2x"> </i><br> Contrary to popular belief, Lorem Ipsum is not simply
                                    </li>

                                </ul>-->
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- page start-->
            <div class="row">
                <div class="col-lg-12">
                    <section class="panel">
                        <header class="panel-heading tab-bg-info">
                            <ul class="nav nav-tabs">
                                <!--<li class="active">
                                    <a data-toggle="tab" href="#recent-activity">
                                        <i class="icon-home"></i>
                                        Daily Activity
                                    </a>
                                </li>-->
                                <li>
                                    <a data-toggle="tab" href="#profile">
                                        <i class="icon-user"></i>
                                        Profile
                                    </a>
                                </li>
                                <li class="">
                                    <a data-toggle="tab" href="#edit-profile">
                                        <i class="icon-envelope"></i>
                                        Edit Profile
                                    </a>
                                </li>
                                <li class="">
                                    <a data-toggle="tab" href="#change-password">
                                        <i class="icon-envelope"></i>
                                        Change Password
                                    </a>
                                </li>
                            </ul>
                        </header>
                        <div class="panel-body">
                            <div class="tab-content">
                                <!-- profile -->
                                <div id="profile" class="tab-pane active">
                                    <section class="panel">
                                        <div class="bio-graph-heading">
                                            Hello I’m <?php echo $FirstName." ".$LastName. " a " .$acc; ?>.
                                        </div>
                                        <div class="panel-body bio-graph-info">
                                            <h1>Personal Information</h1>
                                            <div class="row">
                                                <div class="bio-row">
                                                    <p><span>First Name </span>: <?php echo $FirstName; ?></p>
                                                </div>
                                                <div class="bio-row">
                                                    <p><span>Last Name </span>: <?php echo $LastName; ?></p>
                                                </div>
                                                <div class="bio-row">
                                                    <p><span>Username</span>: <?php echo $user; ?></p>
                                                </div>
                                                <div class="bio-row">
                                                    <p><span>Email </span>: <?php echo $mail; ?></p>
                                                </div>
                                                <div class="bio-row">
                                                    <p><span>Occupation </span>: <?php echo $acc; ?></p>
                                                </div>
                                                <div class="bio-row">
                                                    <p><span>Gender </span>: <?php echo $gender; ?></p>
                                                </div>
                                                <div class="bio-row">
                                                    <p><span>Contact Number</span>: <?php echo $phone; ?></p>
                                                </div>
                                                <div class="bio-row">
                                                    <p><span>Address</span>: <?php echo $adr; ?></p>
                                                </div>
                                            </div>
                                        </div>
                                    </section>
                                    <section>
                                        <div class="row">
                                        </div>
                                    </section>
                                </div>
                                <!-- edit-profile -->
                                <div id="edit-profile" class="tab-pane">
                                    <section class="panel">
                                        <div class="panel-body bio-graph-info">
                                            <h1> Profile Information </h1>
                                            <form class="form-horizontal" method="post" role="form">
                                                <div class="form-group">
                                                    <label class="col-lg-2 control-label">First Name</label>
                                                    <div class="col-lg-6">
                                                        <input type="text" class="form-control" name="first_name" id="f-name" value="<?php echo $FirstName;?>" placeholder="Enter First Name ">
                                                    </div>
                                                </div>
                                                <div class="form-group">
                                                    <label class="col-lg-2 control-label">Last Name</label>
                                                    <div class="col-lg-6">
                                                        <input type="text" class="form-control" name="last_name" value="<?php echo $LastName;?>" id="l-name" placeholder=" ">
                                                    </div>
                                                </div>
                                                <div class="form-group">
                                                    <label class="col-lg-2 control-label">Username</label>
                                                    <div class="col-lg-6">
                                                        <input type="text" name="username" value="<?php echo $username; ?>" class="form-control" id="b-day" placeholder="">
                                                    </div>
                                                </div>
                                                <div class="form-group">
                                                    <label class="col-lg-2 control-label">Email</label>
                                                    <div class="col-lg-6">
                                                        <input type="email" name="email" value="<?php echo $mail;?>" class="form-control" id="email" placeholder=" ">
                                                    </div>
                                                </div>

                                                <div class="form-group">
                                                    <label class="col-lg-2 control-label">Gender</label>
                                                    <div class="col-lg-6">
                                                        <select name="gender" >
                                                            <option><?php echo $gender; ?></option>
                                                            <option>Male</option>
                                                            <option>Female</option>
                                                        </select>
                                                    </div>
                                                </div>
                                                <div class="form-group">
                                                    <label class="col-lg-2 control-label">Cantact Number</label>
                                                    <div class="col-lg-6">
                                                        <input type="number" name="phone" value="<?php echo $phone;?>" class="form-control" id="mobile" placeholder=" ">
                                                    </div>
                                                </div>
                                                <div class="form-group">
                                                    <label class="col-lg-2 control-label">Address</label>
                                                    <div class="col-lg-6">
                                                        <input type="text" name="address" value="<?php echo $adr;?>" class="form-control"  placeholder="http://www.demowebsite.com ">
                                                    </div>
                                                </div>
                                                <div class="form-group">
                                                    <label class="col-lg-2 control-label">Occupation</label>
                                                    <div class="col-lg-6">
                                                        <input type="text" name="design" value="<?php echo $acc?>" class="form-control" id="occupation" placeholder=" ">
                                                    </div>
                                                </div>
                                                <div class="form-group">
                                                    <div class="col-lg-offset-2 col-lg-10">
                                                        <button type="submit" name="edit" class="btn btn-primary">Edit</button>
                                                        <button type="button" class="btn btn-danger">Cancel</button>
                                                    </div>
                                                </div>
                                            </form>
                                            <?php
                                            if(isset($_POST['edit'])){
                                                $fname =$_POST['first_name'];
                                                $lname =$_POST['last_name'];
                                                $user=$_POST['username'];
                                                $mail=$_POST['email'];
                                                //$pass=$_POST['password'];
                                                $sexs=$_POST['gender'];
                                                $phone=$_POST['phone'];
                                                $adr=$_POST['address'];
                                                $acc =$_POST['design'];
                                                try {
                                                    $query = "UPDATE `users` SET first_name='".$fname."', last_name='".$lname."', username='".$user."', email ='".$mail."', gender='".$sexs."', phone='".$phone."',
                                    address='".$adr."', role='Client', design='".$acc."' where username='$user'";
                                                    $pdo->exec($query);
                                                    // header("location : edit_profile.php");
                                                    echo '<script language="javascript">';
                                                    echo 'alert("account updated successfully")';
                                                    echo '</script>';
                                                }catch(PDOException $e){
                                                    die("ERROR: Could not able to execute $query. " . $e->getMessage());
                                                    echo '<script language="javascript">';
                                                    echo 'alert("Update failed")';
                                                    echo '</script>';
                                                }
                                            }
                                            ?>
                                        </div>
                                    </section>
                                </div>
                                <div id="change-password" class="tab-pane">
                                    <section class="panel">
                                        <div class="panel-body bio-graph-info">
                                            <h1> Change Password </h1>
                                            <form class="form-horizontal" method="post" role="form">
                                                <div class="form-group">
                                                    <label class="col-lg-2 control-label">New Password</label>
                                                    <div class="col-lg-6">
                                                        <input type="password" class="form-control" value="" required name="newpass" id="l-name" placeholder=" ">
                                                    </div>
                                                </div>
                                                <div class="form-group">
                                                    <label class="col-lg-2 control-label">Confirm Password</label>
                                                    <div class="col-lg-6">
                                                        <input type="password" name="confirm" required class="form-control" id="b-day" placeholder="">
                                                    </div>
                                                </div>
                                                <div class="form-group">
                                                    <div class="col-lg-offset-2 col-lg-10">
                                                        <button type="submit" name="pass" class="btn btn-primary">Change</button>
                                                    </div>
                                                </div>
                                            </form>
                                            <?php
                                            if(isset($_POST['pass'])) {
                                                $pass = $_POST['newpass'];
                                                $confirm = $_POST['confirm'];
                                                if ($pass == $confirm) {
                                                    try {
                                                        $query = "UPDATE `users` SET password='" . $pass . "' where username='$user'";
                                                        $pdo->exec($query);
                                                        // header("location : edit_profile.php");
                                                        echo '<script language="javascript">';
                                                        echo 'alert("Password changed successfully")';
                                                        echo '</script>';
                                                    } catch (PDOException $e) {
                                                        die("ERROR: Could not able to execute $query. " . $e->getMessage());
                                                        echo '<script language="javascript">';
                                                        echo 'alert("Update failed")';
                                                        echo '</script>';
                                                    }
                                                } else {
                                                    echo '<script language="javascript">';
                                                    echo 'alert("Passwords did not match")';
                                                    echo '</script>';
                                                }
                                            }
                                            ?>
                                        </div>
                                    </section>
                                </div>


                            </div>
                        </div>

                        <!-- page end-->
                    </section>
        </section>
        <!--main content end-->
        <div class="text-center">
            <div class="credits">
                <!--
                  All the links in the footer should remain intact.
                  You can delete the links only if you purchased the pro version.
                  Licensing information: https://bootstrapmade.com/license/
                  Purchase the pro version form: https://bootstrapmade.com/buy/?theme=NiceAdmin
                -->
                <a href="#">Copyright @ Keltech Repairs 2017</a>
            </div>
        </div>
    </section>
    <!-- container section end -->
    <!-- javascripts -->
    <script src="../js/jquery.js"></script>
    <script src="../js/bootstrap.min.js"></script>
    <!-- nice scroll -->
    <script src="../js/jquery.scrollTo.min.js"></script>
    <script src="../js/jquery.nicescroll.js" type="text/javascript"></script>
    <!-- jquery knob -->
    <script src="../assets/jquery-knob/js/jquery.knob.js"></script>
    <!--custome script for all page-->
    <script src="../js/scripts.js"></script>

    <script>
        //knob
        $(".knob").knob();
    </script>


</body>

</html>
