<?php
include('dbcon.php');
if(isset($_POST['upload']))
{    
    $name=$_POST['username'];
    $test=$_POST['testify'];
    //$pro=$_POST['program'];
	$file = rand(1000,100000)."-".$_FILES['image']['name'];
    $file_loc = $_FILES['image']['tmp_name'];
	$file_size = $_FILES['image']['size'];
	$file_type = $_FILES['image']['type'];
	$folder="upload/";

	
	// new file size in KB
	$new_size = $file_size/1024;  
	// new file size in KB
	
	// make file name in lower case
	$new_file_name = strtolower($file);
	// make file name in lower case
	
	$final_file=str_replace(' ','-',$new_file_name);
	
	 if(move_uploaded_file($file_loc,$folder.$final_file))
	{
		if(!(
  $file_type=='application/vnd.openxmlformats-officedocument.wordprocessingml.document' ||
  $file_type=='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' ||
  $file_type=='application/vnd.openxmlformats-officedocument.presentationml.presentation' ||
  $file_type=='application/pdf' ||
  $file_type=='application/msword' ||
  $file_type=='application/doc' ||
  $file_type=='application/jpg' ||
  $file_type=='application/jpeg' ||
  $file_type=='application/png'
  )) {
  	?>
  <script>
		alert('Format is not an acceptable document format click ok to reupload');
        window.location.href='client/testmony.php';
        </script>
  <?php
  }
	else{
		$sql="INSERT INTO testmonies(username,testify,file,type,size) VALUES('$name','$test','$final_file','$file_type','$new_size')";
		mysql_query($sql);
		?>
		<script>
		alert('successfully uploaded');
        window.location.href='client/testmony.php';
        </script>
		<?php
	}
}
	else
	{
		?>
		<script>
		alert('error while uploading file');
        window.location.href='client/testmony.php';
        </script>
		<?php
	}
}
?>